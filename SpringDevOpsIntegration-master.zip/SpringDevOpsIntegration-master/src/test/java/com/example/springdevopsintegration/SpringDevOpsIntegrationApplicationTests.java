package com.example.springdevopsintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDevOpsIntegrationApplicationTests {

    @Test
    void contextLoads() {
    }

}
